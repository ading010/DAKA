# 文件名： __init__
# 创建日期：2020年09月13日09点44分
# 作者：Zhongbr
# 邮箱：zhongbr@icloud.com
from .campus import CampusCard
